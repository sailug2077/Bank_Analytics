create database loan_analysis;
use loan_analysis;
show databases;
select * from finance_1;
select * from finance_2;
select count(*) from finance_1 f1
join finance_2 f2
on f1.id = f2.id;
-- yearwise Funded Amount
select year_issue_d as Year,
concat("$",format(round(sum(funded_Amnt)/1000000,2),2),"","M") as Total_Funded_Amount
from finance_1
group by Year_Issue_d
order by year_issue_d;

-- Total Funded_Amount
select sum(funded_Amnt) as Total_Funded_Amount
from finance_1;
-- for more accuracy in millions rounded to 2 decimal points using concat(add)
select concat("$",format(round(sum(funded_Amnt)/1000000,2),2),"","M") as Tot_Funded_Amount
from finance_1;

-- KPI  1) ## yearwise loan_Amount
select Year_Issue_d as year,
concat("$",format(round(sum(loan_Amnt)/1000000,2),2),"","M") as Total_Loan_Amount
from finance_1
group by year
order by year;

###2. Grade and Sub_grade wise revolving Balance
select grade as Grade, sub_grade as Sub_grade ,
concat("$",format(round(sum(revol_bal)/1000000,2),2),"","M") as Revolving_Balance
 from finance_1 
inner join finance_2 
on (finance_1.id = finance_2.id)
group  by grade, sub_grade
order by grade , sub_grade;

-- only by grade
select grade as Grade, 
concat("$",format(round(sum(revol_bal)/1000000,2),2),"","M") as Revolving_Balance
 from Finance_1
 inner join finance_2
 on finance_1.id = finance_2.id
 group by grade
 order by grade ;

 
### 3. Total Payment for Verified status versus non_Verfied Status

 select verification_status as Verified_Status, 
 concat("$",format(round(sum(total_pymnt)/1000000,2),2),"","M") as Total_Payment
 from finance_1
 inner join finance_2
 on (finance_1.id = finance_2.id)
 group by verification_status
 order by verification_status;
 
### 4. State_Wise ,last_credit_pull_d wise Loan Status
select addr_state as Address_State, loan_status as Loan_Status
from finance_1 
group by  addr_state,loan_status
order by addr_state, loan_status;

##KPI 5 Home Ownership Vs last payment date stats
select home_ownership as Home_Ownership, year_Lst_pmnt_D as Year_Payment
from finance_1 inner join finance_2
on finance_1.id = finance_2.id
group by  home_ownership , year_Lst_pmnt_D 
order by home_ownership desc, year_Lst_pmnt_D desc;


